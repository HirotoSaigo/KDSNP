//
//  data.h
//  KDE
//
//  Created by Kento Kodama on 2/23/15.
//  Copyright (c) 2015 Saigo Laboratoire. All rights reserved.
//
//  This is free software with ABSOLUTELY NO WARRANTY.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
//  02111-1307, USA

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cfloat>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <new>
#include "Eigen/Core"
#include "Eigen/LU"
#include "Eigen/Sparse"
#include "Eigen/QR"
#include "Eigen/Dense"

#include "MatrixExt.h"

using namespace std;
using namespace Eigen;
using namespace EigenExt;

class Genotypes {
private:
     MatrixXd X;    //SNP(genotype) matrix
     unsigned int n;         //number of individuals
     unsigned int p;         //number of SNPs

public:
     virtual bool LoadX(string filename);
     virtual void SetN();
     virtual void SetP();
     virtual MatrixXd& GetX();
     virtual unsigned int GetN();
     virtual unsigned int GetP();
     virtual void ShuffleX(vector<unsigned int> order);
     virtual void ComplementX(unsigned int nrow);
};


class Phenotypes {
private:
     MatrixXd Y;     //phenotype matrix
     int n;          //number of individuals

public:
     virtual bool LoadY(string filename);
     virtual void SetN();
     virtual unsigned int GetN();
     virtual void Centred();
     virtual MatrixXd& GetY();
     virtual vector<unsigned int> SortIndexByY(unsigned int fold);
     virtual void ShuffleY(vector<unsigned int> order);
     virtual void ComplementY(unsigned int nrow);
};
