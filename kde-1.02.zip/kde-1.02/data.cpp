//
//  data.cpp
//  KDE
//
//  Created by Kento Kodama on 2/23/15.
//  Copyright (c) 2015 Saigo Laboratoire. All rights reserved.
//
//  This is free software with ABSOLUTELY NO WARRANTY.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
//  02111-1307, USA

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cfloat>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <new>
#include "Eigen/Core"
#include "Eigen/LU"
#include "Eigen/Sparse"
#include "Eigen/QR"
#include "Eigen/Dense"
#pragma implementation

#include "MatrixExt.h"
#include "data.h"

using namespace std;
using namespace Eigen;
using namespace EigenExt;

bool Genotypes::LoadX(string filename)
{
     return loadMatrixFromFileFast(this->X, filename.c_str());   
}

void Genotypes::SetN()
{
     this->n = this->X.rows();
}

void Genotypes::SetP()
{
     this->p = this->X.cols()/3.0;
}

MatrixXd& Genotypes::GetX()
{
     return this->X;
}

unsigned int Genotypes::GetN()
{
     return this->n;
}

unsigned int Genotypes::GetP()
{
     return this->p;
}

void Genotypes::ShuffleX(vector<unsigned int> order)
{
     MatrixXd shuffle_x(this->n,this->p * 3);
     
     for (int i = 0; i < this->n; ++i) shuffle_x.row(i) = (this->X).row(order[i]);
     this->X = shuffle_x;
}

void Genotypes::ComplementX(unsigned int nrow)
{
     MatrixXd comp_x(this->n+1, this->p * 3);
     comp_x.block(0, 0, this->n, this->p * 3) = this->X;
     comp_x.block(this->n, 0, 1, this->p * 3) = (this->X).row(nrow - 1);
     (this->X).resize(this->n+1, this->p * 3);
     this->X = comp_x;
}


// class Phenotypes
bool Phenotypes::LoadY(string filename)
{
     return loadMatrixFromFileFast(this->Y, filename.c_str());   
}

void Phenotypes::SetN()
{
     this->n = this->Y.rows();
}

void Phenotypes::Centred()
{
     MatrixXd ones(this->n, 1);
     ones << MatrixXd::Ones(this->n, 1);
     this->Y -= ones * (this->Y).mean();
}

MatrixXd& Phenotypes::GetY()
{
     return this->Y;
}

unsigned int Phenotypes::GetN()
{
     return this->n;
}

vector<unsigned int> Phenotypes::SortIndexByY(unsigned int fold)
{
     vector<unsigned int> index(this->n, 0);
     multimap<double, unsigned int> order;
     bool reverse = false;
     for (int i = 0; i < this->n; ++i){
          order.insert( multimap<double, unsigned int>::value_type( this->Y(i,0), i ) );
     }
     multimap<double, unsigned int>::iterator it = order.begin();
     
     for (int i = 0; i < fold; ++i){
          if ( reverse ) {
	        for (int j = this->n/fold; j > 0; --j){
		     index.at(i + (j - 1)* fold) = (*it).second;
                     ++it;
                }
		reverse = false;
          } else {
	        for (int j = 0; j < this->n/fold; ++j){
	             index.at(i + j * fold) = (*it).second;
                     ++it;
		}
		reverse = true;
          }
     }
     
     return index;
}

void Phenotypes::ShuffleY(vector<unsigned int> order)
{
     MatrixXd shuffle_y(this->n, 1);
     
     for (int i = 0; i < this->n; ++i) shuffle_y.row(i) = (this->Y).row(order[i]);
     this->Y = shuffle_y;
}

void Phenotypes::ComplementY(unsigned int nrow)
{
     MatrixXd comp_y(this->n+1, 1);
     comp_y.block(0, 0, this->n, 1) = this->Y;
     comp_y.block(this->n, 0, 1, 1) = (this->Y).row(nrow - 1);
     (this->Y).resize(this->n+1, 1);
     this->Y = comp_y;
}

